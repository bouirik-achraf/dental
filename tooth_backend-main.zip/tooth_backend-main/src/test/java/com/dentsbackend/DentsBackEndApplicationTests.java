package com.dentsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DentsBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
