# Projet Dents

Bienvenue dans notre projet ! Pour faciliter l'accès à la vidéo en raison de sa longueur, nous l'avons téléchargée sur Mega. Il vous suffit de cliquer sur ce lien pour télécharger le fichier ZIP contenant la vidéo.


1. Accédez à la vidéo en suivant le lien Mega mentionné ci-dessus.
2. Une fois le fichier ZIP téléchargé, extrayez son contenu dans le répertoire de votre choix.
3. Pour créer un compte administrateur, utilisez les informations suivantes :
    - **Nom d'utilisateur (Username):** admin
    - **Mot de passe (Password):** admin
    - **Note importante sur le mot de passe :** Le mot de passe est haché pour des raisons de sécurité. Utilisez donc la chaîne suivante :
      ```
      $2a$10$ZRSKr53Nvjb07URwRAfP/eZ2SWchJiP67WIk7MM3mBAtz1pME9hma
      ```
lien MEGA: https://mega.nz/file/MetDgQDS#wlnc8SrHwyXoFZy3fD-KTqBlQDyzJsp4nMUbsV96Ljc


